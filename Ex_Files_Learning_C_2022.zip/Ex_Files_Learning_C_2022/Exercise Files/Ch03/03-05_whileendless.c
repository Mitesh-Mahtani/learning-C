#include <stdio.h>

int main()
{
	while(1)
	{
		printf("I'm endlessly looping! ");
	}

	return(0);
}

