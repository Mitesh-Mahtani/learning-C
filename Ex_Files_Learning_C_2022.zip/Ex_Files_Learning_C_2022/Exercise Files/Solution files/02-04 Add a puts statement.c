#include <stdio.h>

int main()
{
    puts("I am a computer!");
	puts("Thrilled to meet you.");

	return(0);
}

