#include <stdio.h>

int main()
{
    int a,b;

    for(a=1;a<=20;a++)
        printf("%d\n",a);

    b = -10;
    while( b <= 10)
    {
        printf("%d\n",b);
        b = b + 2;
    }
}
