#include <stdio.h>

int main()
{
    printf("Hello!\nMy name is \"Dan\"\n");

    return(0);
}
