#include <stdio.h>

int main()
{
	float temp1,temp2,temp3,temp4;

	temp1 = 74.9;
	temp2 = 73.7;
	temp3 = 75.8;
	temp4 = 78.2;

	printf("Local temperatures:\n");
	printf("Station 1: %.1f\n",temp1);
	printf("Station 2: %.1f\n",temp2);
	printf("Station 3: %.1f\n",temp3);
	printf("Station 4: %.1f\n",temp4);

	return(0);
}

