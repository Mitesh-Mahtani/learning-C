#include <stdio.h>

int main()
{
	puts("I'm a computer!");
	puts("Thrilled to meet you!");

	return(0);
}

