#include <stdio.h>
#include <math.h>

int main()
{
	float p;

	p = pow(2.0,8.0);

	printf("2 to the 8th power is %f\n",p);

	return(0);
}

