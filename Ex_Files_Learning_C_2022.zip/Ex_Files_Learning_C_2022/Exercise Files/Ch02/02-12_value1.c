#include <stdio.h>

int main()
{
	printf("Here is a value: 27\n");

	return(0);
}

