#include <stdio.h>

int main()
{
	char x,y,z;

	x = 'A';
	y = 'B';
	z = 'C';

	printf("It's as easy as %c%c%c\n",x,y,z);

	return(0);
}

