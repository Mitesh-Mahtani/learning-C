#include <stdio.h>

int main()
{
    char a,b,c,*p;

        /* assign 'A' to variable a */
        /* set pointer p to the address of a */
        /* assign variable b to the value addressed by pointer p */
        /* set pointer p to the address of c */
        /* assign the value addressed by pointer p to 'Z' */

    printf("%c %c %c\n",a,b,c);

    return(0);
}
