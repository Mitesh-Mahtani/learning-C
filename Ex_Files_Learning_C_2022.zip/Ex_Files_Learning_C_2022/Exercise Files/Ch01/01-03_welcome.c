#include <stdio.h>

int main()
{
	printf("Welcome to the C Language!\n);
	return(0)
}
